
This is the first release of iReport for NetBeans 6.0.
iReport for NetBeans is available as standalone application based on the NetBeans RCP and as plugin for NetBeans IDE.

For more information about this project, please visit: http://www.jasperforge.org/ireort
The source code for this application is available at http://www.jasperforge.org/ireport/src



