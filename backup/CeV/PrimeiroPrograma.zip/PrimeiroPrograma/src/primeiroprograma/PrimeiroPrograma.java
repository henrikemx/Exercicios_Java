package primeiroprograma;

/**
 * @author henrique
 */
public class PrimeiroPrograma {

    public static void main(String[] args) {
        System.out.println("\nOlá, Mundo !\n");
        System.out.println("Meu primeiro app em Java :D\n");
    }
    
}
